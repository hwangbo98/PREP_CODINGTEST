str_input = input()

left = 0
right =10
while(left<=len(str_input)) :
    print(str_input[left : right])
    left+=10
    right+=10