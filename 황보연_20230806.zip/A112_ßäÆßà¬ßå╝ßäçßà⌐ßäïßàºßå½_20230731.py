
N, M = map(int, input().split())

guitar_str = []

for i in range(M) :
    str_list = list(map(int, input().split()))
    guitar_str.append(str_list)

print(guitar_str)